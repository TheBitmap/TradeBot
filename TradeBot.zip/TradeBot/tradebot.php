<?php
/*****************************************************************************************************
*																									 *
*								 TheBitmap's BitFinex - TradeBot   									 *
*                                                      												 *
*****************************************************************************************************/
require_once('finex.php');
require_once('config.php');
require_once('calc_data.php');

//Get LTC Ticket Stats
$askfinex = json_decode(file_get_contents("https://api.bitfinex.com/v1/pubticker/LTCUSD"), true);

//Error-Check request for Ticker Stats
while (count($askfinex) == 0)
{
	echo "\nError retrieving ticker stats. Will try again.";
	unset($askfinex);
	sleep(3);
	$askfinex = json_decode(file_get_contents("https://api.bitfinex.com/v1/pubticker/LTCUSD"), true);
}

/************************************************ Read-In File Data ****************************************************/
//send API and secret
$trade = new bitfinex($api_key, $api_secret);

//read saved tracking data
$raw_tracking_data = file_get_contents("data/tracking.dat");
$saved_tracking_data = unserialize($raw_tracking_data);

//read saved sell orders 
$raw_cancelled_data = file_get_contents("data/sell_orders.dat");
$cancelled_sell_orders = unserialize($raw_cancelled_data);

//Set date parameters for log files
$date = date('m-d-Y');
$yesterday = date('m-d-Y',strtotime("-1 day"));

//read profit total for current day
$raw_profit_data = file_get_contents("data/daily_profit-$date.dat");
$profit_data = unserialize($raw_profit_data);

//read data of orders executed today
$raw_logs_data = file_get_contents("data/executed_orders-$date.dat");
$logs_data = unserialize($raw_logs_data);

//If a new day has started, archive the previous days logs
if(file_exists("data/executed_orders-$yesterday.dat"))
{
	if (copy("data/executed_orders-$yesterday.dat","data/order_logs/executed_orders-$yesterday.dat"))
		{unlink("data/executed_orders-$yesterday.dat");}
	
	if (copy("data/profit_log-$yesterday.txt","data/profit_logs/profit_log-$yesterday.txt"))
		{unlink("data/profit_log-$yesterday.txt");}
	
	if (copy("data/daily_profit-$yesterday.dat","data/daily_profits/daily_profit-$yesterday.dat"))
		{unlink("data/daily_profit-$yesterday.dat");}
}

/******************************************* Declare Some Useful Variables *********************************************/
$ask = $askfinex['ask'];
$bid = $askfinex['bid'];
$symbol_high = $askfinex['high'];
$symbol_low = $askfinex['low'];
$symbol_mid = $askfinex['mid'];
$exchange_time = $askfinex['timestamp'];


//** !! ** !! ** !! --- BIDDING CONTROL VARIABLES --- !! ** !! ** !! **
//----------------------------------------------------------------------
$trade_symbol = "ltcusd";  //Examples: ltcusd omgusd btcusd ltcbtc... see exchange for all.  
$price_change=1.0075; // Amount of increase to sell_price NOTE: .002 or less is NOT PROFITABLE
$num_of_orders = 35; // Total number of orders to make within the spread
$amount_control = .005; //Amount for each trade relative to total assets in USD. Ex: .005 and $1000 total assest results in $5 trades
$fees=.002; // Total fees should equate to .2% of trade amount (.1% for the initial buy, and .1% for the sell)
$spread=($bid*0.063); //Spread to cover
$increment_amount = round($spread/$num_of_orders,3);   //average increment amount
$target_bid = $bid-($spread/2); //start placing orders at bottom of spread, moving upward and past the current ask.
$bottom_of_range = ($bid - ($spread/2)) - $increment_amount*2;
$bottom_of_range = strval($bottom_of_range);
$top_of_range = ($bid + ($spread/2)) + $increment_amount*2;
$top_of_range = strval($top_of_range);

//Sort tracking data by the 'buy_price'
$ordered_tracking_data = orderBy($saved_tracking_data, 'buy_price');


/******************************************** Cancel Unnecessary Buy Orders  *********************************************/
//Since the BitFinex exchange limits 100 orders per exchange, cancel orders outside the target spread 

//Check for saved buy bids that are outside the spread and cancel them
for($x = 0; $x < count($ordered_tracking_data); $x++)
	{
		//Remove buy orders that are too low
		while ($ordered_tracking_data[$x]['buy_price'] < $bottom_of_range  && $ordered_tracking_data[$x]['side'] == "buy" && $x < count($saved_tracking_data))
		{
			echo "\nBUY Order ID: " .strval($ordered_tracking_data[$x]['id']). " @ " .$ordered_tracking_data[$x]['buy_price']." is under: " .$bottom_of_range;
			$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			
			//error check cancelled-order
			while (count($execute) == 0)
			{
				echo "\nError cancelling order. Will try again.";
				unset($execute);
				sleep(3);
				$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			}
			$x++;
		}
		
		//Remove buy orders that are too high
		while ($ordered_tracking_data[$x]['buy_price'] > $top_of_range && $ordered_tracking_data[$x]['side'] == "buy" && $x < count($saved_tracking_data)) 
		{		
			echo "\nBuy Order ID: " .strval($ordered_tracking_data[$x]['id']). " @ " .$ordered_tracking_data[$x]['buy_price']." is over: " .$top_of_range;
			$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			
			//error check cancelled-order
			while (count($execute) == 0)
			{
				echo "\nError cancelling order. Will try again.";
				unset($execute);
				sleep(3);
				$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			}
			$x++;
		}
	
		//Cancell sell orders that are too high, but store them so they can be replaced when the price rises again
		while ($ordered_tracking_data[$x]['sell_price'] > ($top_of_range+($increment_amount*15)) && $ordered_tracking_data[$x]['side'] == "sell" && $x < count($saved_tracking_data)) 
		{		
			echo "\nSaving - Sell Order ID: " .strval($ordered_tracking_data[$x]['id']). " @ " .$ordered_tracking_data[$x]['buy_price']." is over: " .$top_of_range;
			$cancelled_sell_orders[] = $ordered_tracking_data[$x];
			$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			
			//error check cancelled-order
			while (count($execute) == 0)
			{
				echo "\nError cancelling order. Will try again.";
				unset($execute);
				sleep(3);
				$execute = $trade->cancel_order($ordered_tracking_data[$x]['id']);
			}
			$x++;
		}
	} 

	
/***************************** Get Balance and List of Live Orders  *****************************/
//Get and show account balances
$balance = $trade->fetch_balance();	

//error check balances
while (count($balance) == 0 || (count($balance) == 1 && $balance[0]['type'] == false))
{
	echo "\nError retrieving account balaces. Will try again.";
	unset($balance);
	sleep(3);
	$balance = $trade->fetch_balance();	
}

//Determines auto bid amount
$calcdAmount = strval(determineAmount($balance, $symbol_mid, $amount_control));
	
//Store USD available for use in $cash_available	
$cash_available=show_balance($balance);

//Get Open Orders From Bitfinex
$orders = $trade->fetch_orders();

//error check orders
while (count($orders) == 0 || (count($orders) == 1 && $orders[0]['id'] == false))
{
	echo "\nError retrieving order list. Will try again.";
	unset($orders);
	sleep(3);
	$orders = $trade->fetch_orders();	
}

//Remove any orders that do not match $trade_symbol
for($sweep=0; $sweep < count($orders); $sweep++)
{
	if($orders[$sweep]['symbol'] != $trade_symbol)
	{
		//echo "\nDeleting symbol " .$orders[$sweep]['symbol'];
		array_splice($orders,$sweep,1);
		$sweep--;
	}
}


//Display number of orders currently open
echo "\n\nThere are currently ".count($orders). " open orders.";


/***************************** Compare Saved Orders to Live Orders *****************************/
$os_std = orderBy($saved_tracking_data, 'id');  //order-sorted saved tracking data
$os_orders = orderBy($orders, 'id');   //order-sorted live orders
$stdmax = count($os_std);
$ordmax = count($os_orders);
$stdcount = 0;
$ordcount = 0;

//If an order from in listed in the saved tracking data, but not the live order data, it has been executed -- log the order to be processed
 while ($stdcount < $stdmax)
{	
	//skip anything without an order ID
	while ($os_std[$stdcount]['id'] == false && $stdcount < $stdmax)
	{
		$stdcount++;
		$ordcount++;
	}
	
	while ($os_std[$stdcount]['id'] == $os_orders[$ordcount]['id'] && $stdcount < $stdmax) //  && $ordcount < $ordmax)
	{
		$stdcount++;
		$ordcount++;
	}

	//If saved id is less than the current open order, then saved order isn't live.... log it.  
	while ($os_std[$stdcount]['id'] != $os_orders[$ordcount]['id'] && $stdcount < $stdmax ) // && $ordcount < $ordmax
	{
	$orders_to_process[]=$os_std[$stdcount];	
	$stdcount++;
	}
}

/*****************Begin processing orders that have executed********************************/
//If Orders were executed on the exchange, processby replacing with a buy or sell
if (count($orders_to_process) > 0)
{
//Begin Loop to process all orders
for($m=0; $m < count($orders_to_process); $m++)
	{
	
	//Grab state of executed order
	$get_order_status=($trade->order_status($orders_to_process[$m]['id']));
	
	//error check order status
	while (count($get_order_status) == 0)
		{
			echo "\nError retrieving Order Status. Will try again.";
			unset($get_order_status);
			sleep(3);
			$get_order_status=($trade->order_status($orders_to_process[$m]['id']));
		}
	$order_state[]=$get_order_status;
	
	//If order was cancelled, do nothing
	if ($order_state[$m]['is_cancelled'] == true && $order_state[$m]['executed_amount'] != $order_state[$m]['original_amount'])
		echo "\nOrder ".$order_state[$m]['id']." was cancelled - do nothing";
	
	//If order is executed_amount is equal to 0, then ignore (orders can take a few seconds to show as cancelled)
	else if ($order_state[$m]['is_live'] == 1 || $order_state[$m]['remaining_amount'] != 0)
	{
		//If order is already in tracker, dont add again
		for($ia=0; $ia<count($os_std); $ia++)
		{
			if($os_std[$ia]['id'] == $order_state[$m]['id'])
				$tracked_tripped=1;
		}
		
		if($tracked_tripped == 1)
			echo "\nOrder ".$order_state[$m]['id']." still shows as active - already tracking";
		
		//If for some reason, order status shows live, and order is not being tracked, re-add to tracker
		else
		{
			echo "\nOrder ".$order_state[$m]['id']." still shows as active - will continue tracking";
			$store_order=$order_state[$m];
			$updated_orders[]=$store_order;
			$update_counter= count($updated_orders)-1;
			if($order_state[$m]['side'] == "sell")
			{
				$updated_orders[$update_counter]['buy_price'] = ($order_state[$m]['price']/$price_change);
				$updated_orders[$update_counter]['sell_price'] = $order_state[$m]['price'];
			}
			else
			{
				$updated_orders[$update_counter]['buy_price'] = $order_state[$m]['price'];
				$updated_orders[$update_counter]['sell_price'] = ($order_state[$m]['price']*$price_change);
			}
			$updated_orders[$update_counter]['previous_amount'] = $updated_orders[$update_counter]['original_amount'];
			unset($store_order);
		}
	}
		
	
	//Since order was not cancelled, issue new order
	else
		{
		$symbol=($order_state[$m]['symbol']);
		
		//Log any orders that are processed
		$logs_data[]=$order_state[$m];
					
		//If the previous order was a buy, then issue a sell order
		if($order_state[$m]['side'] == "buy")
			{
			$amount=$order_state[$m]['executed_amount']*1.00;
			$sell_price=round(($order_state[$m]['price']*$price_change),3);
			$sell_price=strval($sell_price);
			echo "\n\nOrder #" .$order_state[$m]['id']." buy order was executed";
			echo "\nActual buy price was: " .$order_state[$m]['avg_execution_price'];
			echo "\nNew sell price will be: " .$sell_price;
			echo "\nSymbol is: " .$symbol;
			echo "\nAmount is: " .$amount;
			
			$place_order=($trade->new_order($symbol, strval($amount), strval($sell_price), "sell", "exchange limit"));
			
			//error check order placement
			while (count($place_order) == 0)
			{
				echo "\nError placing order. Will try again.";
				unset($place_order);
				sleep(3);
				$place_order=($trade->new_order($symbol, strval($amount), strval($sell_price), "sell", "exchange limit"));
			}
			
			$updated_orders[]=$place_order;
			$update_counter= count($updated_orders)-1;
			$updated_orders[$update_counter]['buy_price'] = $order_state[$m]['avg_execution_price'];
			$updated_orders[$update_counter]['sell_price'] = $sell_price;
			$updated_orders[$update_counter]['previous_amount'] = $amount;
			
			echo "\nExecuted:  sell order";
			}
			
		//If the previous order was a sell, then issue a buy order
		if($order_state[$m]['side'] == "sell")
			{
			//New Profit Vars
			$raw_profit = round((($order_state[$m]['price']-$orders_to_process[$m]['buy_price'])*$orders_to_process[$m]['original_amount']),8);
			$trade_fees = round((($order_state[$m]['price']*$orders_to_process[$m]['original_amount'])*$fees),8);
			$this_trades_profit= round(($raw_profit-$trade_fees),8);
			$profit_data += $this_trades_profit;
			$buy_price=round($order_state[$m]['price']/$price_change,3);
						
			echo "\n\nOrder #" .$order_state[$m]['id']." sell order was executed";
			echo "\nNet Profit: " .$raw_profit;
			echo "\nTotal Fees: " .$trade_fees;
			echo "\nTotal Profit for this trade: " .$this_trades_profit;
			echo "\nOld sell price was: " .$order_state[$m]['price'];
			echo "\nNew buy price will be: " .$buy_price;
			echo "\nSymbol is: " .$symbol;
			echo "\nAmount is: " .$calcdAmount;
			
			//log profits
			$log_profits = fopen("data/profit_log-$date.txt", "a");
			fwrite($log_profits, "\n\nOrder ".$order_state[$m]['id'].
						" sold at ". $order_state[$m]['price'].
						" - Fees: ".$trade_fees.
						"  Profit: ".$this_trades_profit.
						"\nCurrent Profit Total: ".$profit_data);
			
			//Place new buy order to replace the executed sell order
			$place_order=($trade->new_order($symbol, strval($calcdAmount), strval($buy_price), "buy", "exchange limit"));
			
			//error check order placement
			while (count($place_order) == 0)
			{
				echo "\nError placing order. Will try again.";
				unset($place_order);
				sleep(3);
				$place_order=($trade->new_order($symbol, strval($calcdAmount), strval($buy_price), "buy", "exchange limit"));	
			}
							
			$updated_orders[]=$place_order;
			$update_counter= count($updated_orders)-1;
			$updated_orders[$update_counter]['buy_price'] = $buy_price;
			$updated_orders[$update_counter]['sell_price'] = round(($orders_to_process[$m]['buy_price']*$price_change),3);
			$updated_orders[$update_counter]['previous_amount'] = $orders_to_process[$m]['original_amount'];
			
			echo "\nExecuted:  sell order";
			}
		} //end of else statement that issues new orders to replace ones execute on exchange 
	} //end of for loop used to process all executed orders
} //end of if statement, deciding if there were any orders executed on the exchange
	

/************************************ Part 2**************************************
At this point, we have $orders, which is all of our open orders from BitFinex, as well as
$updated_orders, which contain any automaticly created replacement buy/sell orders to account for
ones that executed.  The updated orders have tracking data already added. Now we add
tracking data to the open orders, and merge them with the updated orders to have a 
singular data array.***************************************************************/

//copy array of open orders and add tracking elements to fields
$tracking_data = $orders;
for($i=0; $i < count($tracking_data); $i++)
{
	//If this is a sell order, copy the buy_price and previous_amount from saved data
	if ($tracking_data[$i]['side'] == "sell")
	{
		//find previous data and copy
		for($datacount=0, $savedcount=count($saved_tracking_data); $datacount < $savedcount; $datacount++)
		{
			//If previous data exists, copy.  
			if($tracking_data[$i]['id'] == $saved_tracking_data[$datacount]['id'])
			{
				//echo"\nExisting Record found -- copying previous tracking data";
				$tracking_data[$i]['buy_price'] = $saved_tracking_data[$datacount]['buy_price'];
				$tracking_data[$i]['sell_price'] = $tracking_data[$i]['price'];
				$tracking_data[$i]['previous_amount'] = $saved_tracking_data[$datacount]['previous_amount'];
				$datacount = $savedcount;  //If the record is found, end the search
			}
			//Otherwise, create new tracking data
			else if ($datacount == ($savedcount-1))
			{
				//echo"\nNew Trade -- generating tracking data";
				$tracking_data[$i]['buy_price'] = strval(round(($tracking_data[$i]['price']/$price_change),3));
				$tracking_data[$i]['sell_price'] = $tracking_data[$i]['price'];
				$tracking_data[$i]['previous_amount'] = $tracking_data[$i]['remaining_amount'];
				$datacount = $savedcount;  //If the record is found, end the search
			}
		}
	}
	
	//If this is a buy order, copy the sell_price and previous_amount from saved data
	else if ($tracking_data[$i]['side'] == "buy")
	{
		for($datacount=0, $savedcount=count($saved_tracking_data); $datacount < $savedcount; $datacount++)
		{
			if($tracking_data[$i]['id'] == $saved_tracking_data[$datacount]['id'])
			{
				$tracking_data[$i]['sell_price'] = strval(round(($orders[$i]['price']*$price_change),3));
				$tracking_data[$i]['buy_price'] =$orders[$i]['price'];
				$tracking_data[$i]['previous_amount'] = $saved_tracking_data[$datacount]['previous_amount'];
				$datacount = $savedcount;
			}
			
			//Otherwise, create new tracking data
			else if ($datacount == ($savedcount-1))
			{
				//echo"\nNew Trade -- generating tracking data";
				$tracking_data[$i]['buy_price'] = $tracking_data[$i]['price'];
				$tracking_data[$i]['sell_price'] = strval(round($tracking_data[$i]['price']*$price_change),3);
				$tracking_data[$i]['previous_amount'] = $tracking_data[$i]['remaining_amount'];
				$datacount = $savedcount;  //If the record is found, end the search
			}
		}
	}
}	

//copy any newly created updated orders into tracking data
if (count($updated_orders) > 0)
{
	for($p=0, $q=count($tracking_data); $p <  count($updated_orders); $p++, $q++){
	$tracking_data[$q] = $updated_orders[$p];}
}


/****************************************************************************
Orders have been updated, and we have a database with tracking data.  Now we 
need to open new buy orders, but ONLY IF there is not a sell pending with the
same original buy range****************************************************/

//Sort data by price
$price_sort = orderBy($tracking_data, 'buy_price');
$sell_price_sort = orderBy($tracking_data, 'sell_price');
$cancelled_sort	= orderBy($cancelled_sell_orders, 'buy_price');

//Generate a list of prices.  Set start point
$psortlen=count($price_sort);
$cansortlen=count($cancelled_sort);
$psortinc=0;
$spsortinc=0;
$cansortinc=0;
echo "\n\nSpread: ".$spread;
$real_starting = round(($target_bid + $increment_amount/2),3);
echo "\nStarting Ask: " .$real_starting;
echo "\nIncrement Amount:" .$increment_amount; 
echo "\nStarting buy_price:" .$price_sort[$psortinc]['buy_price']; 
echo "\nStarting sell_price:" .$sell_price_sort[$spsortinc]['sell_price']."\n"; 
	

/******************************* Placing Orders **********************************/
for ($order_count=0; $order_count< $num_of_orders; $order_count++)
{
	//Update spread and increment, so increment will adjust as price changes
	$spread=($target_bid*0.06); //Spread to cover
	$increment_amount = $spread/$num_of_orders; 
	$increment_amount = round($increment_amount*1.1,3);

	//If buy_price start lower than the current buy range, progress through array
	while ($price_sort[$psortinc]['buy_price'] <= $target_bid && $psortinc < $psortlen)
	{
	//	echo "\nbuy price is ".$price_sort[$psortinc]['buy_price'];
		$psortinc++;
	//	echo "\nnow it is ".$price_sort[$psortinc]['buy_price'];
	}
	//If sell_price_sort start lower than the current buy range, progress through array
	while ($sell_price_sort[$spsortinc]['sell_price'] <= $target_bid && $spsortinc < $psortlen)
	{
		$spsortinc++;
	}

	//If a previously cancelled sell order exists in the target range, reinstate the sell order
	if($cancelled_sort[$cansortinc]['buy_price'] >= $target_bid && $cancelled_sort[$cansortinc]['buy_price'] <= ($target_bid+$increment_amount) && $cansortinc < $cansortlen )
	{
		$tdcount = count($tracking_data);
		
		echo "\n#".(1+$order_count)." Reinstating Sell Order! BUY Order for now exist at ".$cancelled_sort[$cansortinc]['buy_price'];
							
			$place_order=$trade->new_order($cancelled_sort[$cansortinc]['symbol'], $cancelled_sort[$cansortinc]['original_amount'],$cancelled_sort[$cansortinc]['price'],
													 $cancelled_sort[$cansortinc]['side'], "exchange limit");
			//error check order placement
			while (count($place_order) == 0)
			{
				echo "\nError reinstating order. Will try again.";
				unset($place_order);
				sleep(3);
				$place_order=$trade->new_order($cancelled_sort[$cansortinc]['symbol'], $cancelled_sort[$cansortinc]['original_amount'],$cancelled_sort[$cansortinc]['price'],
													 $cancelled_sort[$cansortinc]['side'], "exchange limit");
			}
					
		$tracking_data[] = $place_order;	
		$target_bid += ($increment_amount+0.001);
		$temp_store = strval($cancelled_sort[$cansortinc]['price']/$price_change);
		$tracking_data[$tdcount]['buy_price'] = $cancelled_sort[$cansortinc]['buy_price'];
		$tracking_data[$tdcount]['sell_price'] = $cancelled_sort[$cansortinc]['sell_price'];
		$tracking_data[$tdcount]['previous_amount'] = $cancelled_sort[$cansortinc]['previous_amount'];
		array_splice($cancelled_sort, $cansortinc, 1);
	}	
	
	//If buy price is in the range, don't bid
	else if($price_sort[$psortinc]['buy_price'] >= $target_bid && $price_sort[$psortinc]['buy_price'] <= ($target_bid+$increment_amount) && $psortinc < $psortlen )
	{
		echo "\n#".(1+$order_count)." a BUY Order for #".$price_sort[$psortinc]['id']." will exist at "  . $price_sort[$psortinc]['buy_price'];
		$target_bid += ($increment_amount+0.001);
		$psortinc++;		
	}

	//If sell price is in the range, don't bid
	else if($sell_price_sort[$spsortinc]['sell_price'] >= $target_bid && $sell_price_sort[$spsortinc]['sell_price'] <= ($target_bid+$increment_amount) && $spsortinc < $psortlen )
	{
		echo "\n#".(1+$order_count)." a SELL Order for #".$sell_price_sort[$spsortinc]['id']." will exist at "  . $sell_price_sort[$spsortinc]['sell_price'];
		$target_bid += ($increment_amount+0.001);
		$spsortinc++;		
	}	
		
	//otherwise, place bid		

	else
	{
		//Don't bid if there aren't enough funds
		if ($cash_available < ($profit_data/2)+10)
		{	
		echo "\n#".(1+$order_count)." Low funds: ".$cash_available." Minimum required: ".(10+$profit_data/2). " for target ".$target_bid;
		$target_bid += ($increment_amount+0.001);
		}

		//If there are enough funds, place orders
		else
		{
			//Moving target bid to center of bid range
			$store_target_bid = $target_bid;
			$target_bid += round(($increment_amount/2),3);				
			$target_bid = strval($target_bid);
			$tdcount = count($tracking_data);
						
			//If target is lower than current bid, place a limit buy
			if ($target_bid <= $bid)
			{
				echo "\n#".(1+$order_count)." Placing exchange limit buy order buy @ "  .$target_bid;
				
				$place_order=$trade->new_order($trade_symbol, $calcdAmount, $target_bid, "buy", "exchange limit");
				
				//error check order placement
				while (count($place_order) == 0)
				{
					echo "\nError placing order. Will try again.";
					unset($place_order);
					sleep(3);
					$place_order=$trade->new_order($trade_symbol, $calcdAmount, $target_bid, "buy", "exchange limit");
				}
				$tracking_data[] = $place_order;	
			}
			
			//else target is above bid, place a STOP limit buy
			else
			{				
				echo "\n#".(1+$order_count)." Placing exchange stop limit buy order buy @ "  .$target_bid;
				
				$place_order=$trade->new_stop_order($trade_symbol, $calcdAmount, $target_bid, "buy", "exchange stop limit", $target_bid);
				
				//error check order placement
				while (count($place_order) == 0)
				{
					echo "\nError placing order. Will try again.";
					unset($place_order);
					sleep(3);
					$place_order=$trade->$trade->new_stop_order($trade_symbol, $calcdAmount, $target_bid, "buy", "exchange stop limit", $target_bid);
				}
				$tracking_data[] = $place_order;						
			}
			
			$cash_available -= ($tracking_data[$tdcount]['original_amount']*$target_bid);
			$tracking_data[$tdcount]['buy_price'] =  strval($target_bid);
			$tracking_data[$tdcount]['sell_price'] = strval($tracking_data[$tdcount]['buy_price']*$price_change);
			$tracking_data[$tdcount]['previous_amount'] = $tracking_data[$tdcount]['original_amount'];  
			
			//Move target bid back for continuation of order placement
			$target_bid=$store_target_bid;
			$target_bid += $increment_amount; //$target_bid += ($increment_amount+0.001);
		
		} //End of if-statement that allows bidding if funds exist
		
	}
	//Re-Initialize sorted by price data -- this will ensure that sell/buy ranges do not overlap
	$price_sort = orderBy($tracking_data, 'buy_price');
	$sell_price_sort = orderBy($tracking_data, 'sell_price');
	$psortlen=count($price_sort);
	$psortinc=0;
	$spsortinc=0;		
			
} // End of if-statement of for-loop that manages bidding	

echo "\n\nTotal profits for $date: " .$profit_data."\n";

/****************************** Write Data to Files *************************************/
	
//Write Tracking File
$prepared_tracking_data = serialize($tracking_data);
file_put_contents("data/tracking.dat", $prepared_tracking_data);

//Write Sell Orders File
$prepared_cancelled_data = serialize($cancelled_sort);
file_put_contents("data/sell_orders.dat", $prepared_cancelled_data);

//Write Profit File
$prepared_profit_data = serialize($profit_data);
file_put_contents("data/daily_profit-$date.dat", $prepared_profit_data);

//Write Logs File
$prepared_logs_data = serialize($logs_data);
file_put_contents("data/executed_orders-$date.dat", $prepared_logs_data);

session_destroy(); 

?>