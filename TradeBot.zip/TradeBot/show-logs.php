<?php
$date = date('m-d-Y');

$raw_logs_data = file_get_contents("data/executed_orders-$date.dat");
$saved_logs_data = unserialize($raw_logs_data);

//Make orders.txt containing all array data to view
$f = fopen("orders.txt", "w");
for($i=0; $i<count($saved_logs_data); $i++)
	{
		fwrite($f, print_r($saved_logs_data[$i], true));
	}
	
//fwrite($f, "\n test test test");
fclose($f); 

unset($f);

$total_profits = 0;
//Create profits.txt, profits per trade
$f = fopen("profits.txt", "w");
for($i=0; $i<count($saved_logs_data); $i++)
	{
		if ($saved_logs_data[$i]['side'] == "sell")
		{			
			//Calculate Profit from trade.  Total fees are approx 0.2%
			$amount=$saved_logs_data[$i]['executed_amount'];
			$buy_price = ($saved_logs_data[$i]['avg_execution_price']/1.0075);
			$total_fees = (($saved_logs_data[$i]['price']*$amount)*.002);
			$raw_profit = (($saved_logs_data[$i]['price']-$buy_price)*$amount);
			$this_trades_profit= round(($raw_profit-$total_fees),8);
							
			fwrite($f, "\nOrder ".$saved_logs_data[$i]['id'].
							" sold at ". $saved_logs_data[$i]['price'].
							" - Fees: ".$total_fees.
							"  Profit: ".$this_trades_profit);
			
			$total_profits += $this_trades_profit;
			
			//log profits
			$log_profits = fopen("data/profit_log2-$date.txt", "a");
			fwrite($log_profits, "\n\nOrder ".$saved_logs_data[$i]['id'].
						" sold at ".$saved_logs_data[$i]['price'].
						" - Fees: ".(($saved_logs_data[$i]['price']*$amount)*.002).
						"  Profit: ".$this_trades_profit.
						"\nCurrent Profit Total: ".$total_profits);
		
		
		
		
		}
	}
fwrite($f, "\n\nTotal profits from log are: ".$total_profits);	
	
fclose($f); 


?>