<?php

//Show the balance, return USD available to use
function show_balance($balance)
{
	$balarrlength = count($balance);
	echo "\n\n[-------Balances-------]\n";
	for($i=0; $i < $balarrlength; $i++)
	{
		echo $balance[$i]['type']." ".
			 $balance[$i]['currency']." ".
		
		round($balance[$i]['available'],2)."\n";
		 
		if ($balance[$i]['type'] == "exchange" && $balance[$i]['currency'] == "usd")
			$exchange_balance=$balance[$i]['available'];
	}
	return $exchange_balance;
}

//Sort array by a given field
function orderBy($data, $field)
  {
    $code = "return strcmp(\$a['$field'], \$b['$field']);";
    usort($data, create_function('$a,$b', $code));
    return $data;
  }

//Calculate and return the amount of LTC to purchase
function determineAmount($balances, $ltcmid, $amount_var)
{
	for ($az=0; $az<count($balances); $az++)
	{
		if($balances[$az]['type'] == "exchange" && $balances[$az]['currency'] == "usd")
		$amountusd = $balances[$az]['amount'];
		if($balances[$az]['type'] == "exchange" && $balances[$az]['currency'] == "ltc")
		$amountltc = $balances[$az]['amount']*$ltcmid;
	}
	$totalamount=$amountltc+$amountusd;
	echo "\n\nCurrent Value of Total Assets: ".$totalamount;
	$determinedAmount=round((($totalamount*$amount_var)/$ltcmid),3);
	echo "\nCalculated Amount to Purchase: ".$determinedAmount;
	return $determinedAmount;	
}	
  
?>
