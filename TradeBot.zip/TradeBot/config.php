<?php
$api_key = "Your API Key Here";
$api_secret = "Your API Secret Here";
?>