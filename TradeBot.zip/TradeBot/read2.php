<?php

$raw_tracking_data = file_get_contents("data/tracking.dat");
$saved_tracking_data = unserialize($raw_tracking_data);

	//Sort list of orders by price
	

  
  function orderBy($data, $field)
  {
    $code = "return strcmp(\$a['$field'], \$b['$field']);";
    usort($data, create_function('$a,$b', $code));
    return $data;
  }
  

$total_owned =0;
  $price = orderBy($saved_tracking_data, 'buy_price');
//	array_splice($price,0,1);
$todelete=0;
for ($i=0, $j=1; $i < count($price); $i++, $j++)
{
	echo "\nID: ".$price[$i]['id']." " .$price[$i]['remaining_amount']." of ".$price[$i]['side'].
	 " buy: " .$price[$i]['buy_price']. " sell: ".$price[$i]['sell_price'].
	 " - Currently @ " .$price[$i]['price'];
	 if($price[$i]['side'] == "sell")
	 $total_owned+=$price[$i]['remaining_amount'];

	if($price[$i]['id'] == $price[$j]['id'])
	{
		echo"\nDELETE DUPLICATE";
		$todelete++;
	}

	
}
//print_r($price);


echo "\nTotal to delete: " .$todelete. " Total LTC Owned: " .$total_owned;



?>