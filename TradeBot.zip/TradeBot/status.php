<?php
// This version (NR) does NOT round anything, and wil use the maximum amount of decimal places available

require_once('finex.php');
require_once('config.php');

$askfinex = json_decode(file_get_contents("https://api.bitfinex.com/v1/pubticker/LTCUSD"), true);

/***************************** Read-In File Data *****************************/
//send API and secret
$trade = new bitfinex($api_key, $api_secret);

$balance = $trade->fetch_balance();	
//$order_state[]=($trade->order_status(3129499458));



print_r($balance);



?>