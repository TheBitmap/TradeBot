<?php

$raw_tracking_data = file_get_contents("data/sell_orders.dat");
$saved_tracking_data = unserialize($raw_tracking_data);

	//Sort list of orders by price
	

  
  function orderBy($data, $field)
  {
    $code = "return strcmp(\$a['$field'], \$b['$field']);";
    usort($data, create_function('$a,$b', $code));
    return $data;
  }
  $ltctobid=0;
  $total_owned =0;
  $price = orderBy($saved_tracking_data, 'buy_price');
//	array_splice($price,0,1);
for ($i=0; $i < count($price); $i++)
{
	echo "\nID: ".$price[$i]['id']." " .$price[$i]['remaining_amount']." of ".$price[$i]['side'].
	 " buy: " .$price[$i]['buy_price']. " sell: ".$price[$i]['sell_price'].
	 " - Currently @ " .$price[$i]['price'];
	 $total_owned+=$price[$i]['remaining_amount'];
	
		 
		 
		 if ($price[$i]['buy_price'] < 42.5)
		 {
		 $ltctobid+= ($price[$i]['remaining_amount']);
		// array_splice($price,$i,1);
		// $i--;
		 }
			if($price[$i]['price'] > 45)
			{
				array_splice($price,$i,1);
			$i--;		
			}		
}
/*for ($i=0; $i < count($price); $i++)
{
	echo "\nID: ".$price[$i]['id']." " .$price[$i]['remaining_amount']." of ".$price[$i]['side'].
	 " buy: " .$price[$i]['buy_price']. " sell: ".$price[$i]['sell_price'].
	 " - Currently @ " .$price[$i]['price'];
	 $total_owned+=$price[$i]['remaining_amount'];
}*/

echo "\nTotal LTC Owned: " .$total_owned;

//print_r($price);
echo "\nTotal LTC to bid at 42.5: " .$ltctobid;

//Write Logs File
//$prepared_cancelled_data = serialize($price);
//file_put_contents("data/sell_orders.dat", $prepared_cancelled_data);

?>